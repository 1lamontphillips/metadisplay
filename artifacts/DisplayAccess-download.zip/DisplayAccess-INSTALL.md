# Display Access sample: install and test

This is Meta's official Android DisplayAccess sample, configured for Developer Mode. It displays the sample's car-maintenance guide. It does not stream your phone's camera.

## Phone requirements

- Android 12 or newer.
- Meta's companion app installed and your Meta Ray-Ban Display glasses paired, powered on, unfolded, and nearby.
- Meta Developer Mode enabled for the linked glasses, following Meta's current instructions. The APK uses Meta's documented development application ID and client token values of `0`; production credentials are not needed for this test.
- Current compatible companion app, glasses firmware, and DAT app on the glasses.

## Install on your Android phone

Download `DisplayAccess-debug.apk` onto the phone and open it. If Android asks, allow the app you used to open the APK to install this downloaded app. Follow the Android installation prompts.

Alternatively, connect the phone to your own computer by USB, enable Android USB debugging, and accept the phone's debugging authorization prompt. With Android platform-tools available on that computer:

```sh
adb devices
adb install -r DisplayAccess-debug.apk
adb shell am start -n com.meta.wearable.dat.externalsampleapps.displayaccess/.MainActivity
```

A phone connected to your own computer is not automatically connected to this cloud workspace. Do not expose Android debugging publicly.

## Confirm content on real glasses

1. Open **Display Access** and grant the requested Nearby devices/Bluetooth permission.
2. In Settings, tap **Connect my glasses**. Complete the Meta companion app registration and check the sample reports **Registered**.
3. If prompted, use **Update firmware** or **Update app on glasses**, then retry the connection. Developer Mode may need to be enabled again after updates.
4. Open **Samples → Car maintenance guide → Try it**.
5. Look through the glasses and confirm the tutorial choices appear. Select **Oil change → Start** and check **Step 1** appears.
6. Verify **Next** advances the instructions and **Previous** goes back. Optionally test **Watch video** and note any playback error separately.

Record the phone model, Android version, whether registration says Registered, what actually appears in the glasses, and any exact error message. Do not include tokens or other credentials.

**Developer preview**, Chrome preview, and in-app previews use a simulated device and do not establish that content appears on physical glasses. The hardware test remains unverified until it is performed on the paired phone and glasses.

## Source and build

- Official source: https://github.com/facebook/meta-wearables-dat-android/tree/main/samples/DisplayAccess
- Source directory: `/workspace/meta-wearables-official/meta-wearables-dat-android-main/samples/DisplayAccess`
- Rebuild in this cloud environment: `bash /workspace/android-setup/build-displayaccess.sh`
- Local configuration: ignored `local.properties` provides the Android SDK path and the documented Developer Mode values. No sample source or dependency declarations were changed.
- This is a debug-signed development build, not a production release.
